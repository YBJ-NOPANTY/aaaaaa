import numpy as np


def readTxt(x1, y1, x2, y2, conf, cls_pred, path):
    f = open("/home/haha/PyTorch-YOLOv3-master/output/txt/" + path[15:-4] + ".txt", 'w')
    for i in range(len(x1)):
        if (int)(cls_pred[i].item()) == 0:
            f.write("no_mask")
        elif (int)(cls_pred[i].item()) == 1:
            f.write("incorrect_mask")
        elif (int)(cls_pred[i].item()) == 2:
            f.write("correct_mask")
        f.write(" ")
        f.write(str((conf[i].item())))
        f.write(" ")
        f.write(str((int)(np.round(x1[i].item()))))
        f.write(" ")
        f.write(str((int)(np.round(y1[i].item()))))
        f.write(" ")
        f.write(str((int)(np.round(x2[i].item()))))
        f.write(" ")
        f.write(str((int)(np.round(y2[i].item()))))
        f.write("\n")
    f.close()
